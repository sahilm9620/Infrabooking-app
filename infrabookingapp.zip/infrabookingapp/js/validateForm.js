// Login Form Validation
function validateLoginForm() {
    //collect form data in JavaScript variables  
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    var id_email = document.getElementById("email");
    var id_error_msg = document.getElementById("blankMsg");
    var id_btn_login = document.getElementById("btn_login");
    var id_password = document.getElementById('password');

    // email validation
    if (email == "" || email === null) {
        id_error_msg.innerHTML = "*Email Required";
        id_email.style.borderColor = "red";
        id_btn_login.setAttribute("disabled", "disabled");
        return false;
    }
    if (!(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email))) {
        id_error_msg.innerHTML = "*Invalid Email ID ";
        id_email.style.borderColor = "red";
        id_btn_login.setAttribute("disabled", "disabled");
        return false;
    } else {
        id_error_msg.innerHTML = "";
        id_email.style.borderColor = "";
        id_btn_login.removeAttribute("disabled");

    }


    //check empty password field  
    if (password == "" || password === null) {
        id_error_msg.innerHTML = "*Password Required";
        id_password.style.borderColor = "red";
        id_btn_login.setAttribute("disabled", "disabled");
        return false;
    } else {
        id_error_msg.innerHTML = "";
        id_password.style.borderColor = "";
        id_btn_login.removeAttribute("disabled");
    }




    //minimum password length validation  
    if (password.length < 8) {
        id_error_msg.innerHTML = "*Password must contain atleast 8 characters";
        id_password.style.borderColor = "red";
        id_btn_login.setAttribute("disabled", "disabled");
        return false;
    } else {
        id_error_msg.innerHTML = "";
        id_password.style.borderColor = "";
        id_btn_login.removeAttribute("disabled", "disabled");
    }


    //maximum length of password validation  
    if (password.length > 15) {
        id_error_msg.innerHTML = "*Password length must not exceed 15 characters";
        id_password.style.borderColor = "red";
        id_btn_login.setAttribute("disabled", "disabled");
        return false;
    } else {
        id_error_msg.innerHTML = "";
        id_password.style.borderColor = "";
        id_btn_login.removeAttribute("disabled", "disabled")
    }


}

// Registartion Form Validation
function validateRegisterForm() {
    //collect form data in JavaScript variables 
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var pw1 = document.getElementById("password").value;
    var pw2 = document.getElementById("cpassword").value;





    //check empty first name field  
    if (name == "" || name === null) {
        document.getElementById("blankMsg").innerHTML = "*Name Required";
        document.getElementById('name').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    }

    //character data validation  
    else if (!isNaN(name)) {
        document.getElementById("blankMsg").innerHTML = "*Only characters are allowed";
        document.getElementById('name').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else if (name.length <= 3) {
        document.getElementById("blankMsg").innerHTML = "*Name must contain atleast 4 characters";
        document.getElementById('room_name').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('name').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")
    }



    if (email == "" || email === null) {
        document.getElementById("blankMsg").innerHTML = "*Email Required";
        document.getElementById('email').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    }
    if (!(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email))) {
        document.getElementById("blankMsg").innerHTML = "*Invalid Email ID ";
        document.getElementById('email').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('email').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")

    }

    //check empty password field  
    if (pw1 == "" || pw1 === null) {
        document.getElementById("blankMsg").innerHTML = "*Password Required";
        document.getElementById('password').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('password').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")
    }


    //check empty confirm password field  
    if (pw2 == "" || pw2 === null) {
        document.getElementById("blankMsg").innerHTML = "*Confirm Password Required";
        document.getElementById('cpassword').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('cpassword').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")
    }


    //minimum password length validation  
    if (pw1.length < 8) {
        document.getElementById("blankMsg").innerHTML = "*Password must contain atleast 8 characters";
        document.getElementById('password').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('password').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")
    }


    //maximum length of password validation  
    if (pw1.length > 15) {
        document.getElementById("blankMsg").innerHTML = "*Password length must not exceed 15 characters";
        document.getElementById('password').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('password').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")

    }


    if (pw1 != pw2) {
        document.getElementById("blankMsg").innerHTML = "*Password and Confirm Password Did Not Match";
        document.getElementById('password').style.borderColor = "red";
        document.getElementById('cpassword').style.borderColor = "red";
        document.getElementById("btn_register").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('password').style.borderColor = "";
        document.getElementById('cpassword').style.borderColor = "";
        document.getElementById("btn_register").removeAttribute("disabled")
    }

}


// Validate Add room Form
function validateAddRoomForm() {
    //collect form data in JavaScript variables  


    var room_name = document.getElementById("room_name").value;
    var capacity = document.getElementById("capacity").value;


    if (room_name == "" || room_name === null) {
        document.getElementById("blankMsg").innerHTML = "*Room Name Required";
        document.getElementById('room_name').style.borderColor = "red";
        document.getElementById("btn_add_room").setAttribute("disabled", "disabled");
        return false;
    } else if (room_name.length <= 3) {
        document.getElementById("blankMsg").innerHTML = "*Room Name must contain atleast 4 characters";
        document.getElementById('room_name').style.borderColor = "red";
        document.getElementById("btn_add_room").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('room_name').style.borderColor = "";
        document.getElementById("btn_add_room").removeAttribute("disabled")

    }


    //check capacity password field  
    if (capacity == "" || capacity === null) {
        document.getElementById("blankMsg").innerHTML = "*Capacity Required";
        document.getElementById('capacity').style.borderColor = "red";
        document.getElementById("btn_add_room").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('capacity').style.borderColor = "";
        document.getElementById("btn_add_room").removeAttribute("disabled")
    }




    //minimum capacity length validation  
    if (capacity < 1) {
        document.getElementById("blankMsg").innerHTML = "*Capacity must be greater than 0";
        document.getElementById('capacity').style.borderColor = "red";
        document.getElementById("btn_add_room").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('capacity').style.borderColor = "";
        document.getElementById("btn_add_room").removeAttribute("disabled")
    }


    //maximum length of capacity validation  
    if (capacity > 150) {
        document.getElementById("blankMsg").innerHTML = "*Capacity must be less than 150";
        document.getElementById('capacity').style.borderColor = "red";
        document.getElementById("btn_add_room").setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('capacity').style.borderColor = "";
        document.getElementById("btn_add_room").removeAttribute("disabled");
    }


}




// Book Room Validation

function validateBookRoomForm() {
    //collect form data in JavaScript variables  
    var date = document.getElementById("date").value;
    var description = document.getElementById("description").value;

    var id_btn_check_available = document.getElementById("btn_check_available");

    // date validation
    if (date == "" || date === null) {
        document.getElementById("blankMsg").innerHTML = "*Date Required";
        document.getElementById('date').style.borderColor = "red";
        id_btn_check_available.setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('date').style.borderColor = "";
        id_btn_check_available.removeAttribute("disabled");

    }


    //check empty description field  
    if (description == "" || description === null) {
        document.getElementById("blankMsg").innerHTML = "*description Required";
        document.getElementById('description').style.borderColor = "red";
        id_btn_check_available.setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('description').style.borderColor = "";
        id_btn_check_available.removeAttribute("disabled");
    }




    //minimum description length validation  
    if (description.length < 8) {
        document.getElementById("blankMsg").innerHTML = "*description must contain atleast 8 characters";
        document.getElementById('description').style.borderColor = "red";
        id_btn_check_available.setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('description').style.borderColor = "";
        id_btn_check_available.removeAttribute("disabled");
    }


    //maximum length of description validation  
    if (description.length > 60) {
        document.getElementById("blankMsg").innerHTML = "*description length must not exceed 60 characters";
        document.getElementById('description').style.borderColor = "red";
        id_btn_check_available.setAttribute("disabled", "disabled");
        return false;
    } else {
        document.getElementById("blankMsg").innerHTML = "";
        document.getElementById('description').style.borderColor = "";
        id_btn_check_available.removeAttribute("disabled");
    }


}