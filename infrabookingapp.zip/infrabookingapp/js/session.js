function Login_session() {


    sessionStorage.setItem("username", "sahil");
    alert("Login Successful...");
    check_session();
}

function check_session() {

    if (sessionStorage.getItem("username") === null) {
        document.getElementById("nav_logout").innerHTML = "";
        document.getElementById("nav_show_all_room").innerHTML = "";
        document.getElementById("nav_add_room").innerHTML = "";
        document.getElementById("nav_book_room").innerHTML = "";
        document.getElementById("nav_login").innerHTML = "LOGIN";
        document.getElementById("nav_registration").innerHTML = "REGISTRATION";

    } else {
        document.getElementById("nav_logout").innerHTML = "LOGOUT";
        document.getElementById("nav_show_all_room").innerHTML = "SHOW ALL ROOM";
        document.getElementById("nav_add_room").innerHTML = "ADD ROOM";
        document.getElementById("nav_book_room").innerHTML = "BOOK ROOM";
        document.getElementById("nav_login").innerHTML = "";
        document.getElementById("nav_registration").innerHTML = "";
    }
}

function clearSession() {
    sessionStorage.removeItem("username");
    check_session();
}